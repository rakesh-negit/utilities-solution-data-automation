from arcrest.security import AGOLTokenSecurityHandler
from arcrest.agol import FeatureService
from arcrest.agol import FeatureLayer
from arcrest.common.filters import LayerDefinitionFilter
import arcrest
import json
if __name__ == "__main__":
    username = "SolutionsPres"
    password = "123pliney"
    service_url = "http://services2.arcgis.com/PWJUSsdoJDp7SgLj/arcgis/rest/services/WaterForBackup/FeatureServer"
    layer_url = "http://services2.arcgis.com/PWJUSsdoJDp7SgLj/arcgis/rest/services/WaterForBackup/FeatureServer/2"
    admin_url = "https://services2.arcgis.com/PWJUSsdoJDp7SgLj/ArcGIS/rest/admin/WaterForBackup/FeatureServer"
    service_name = 'WaterForBackup'
    itemId = '3bd090a618ae4241b585f3260b9d37c1'
    proxy_port = None
    proxy_url = None
    
    agolSH = AGOLTokenSecurityHandler(username=username,
                                      password=password)
    
    step1 = True
    step2 = False
    step3 = False            
    step4 = False
    step5 = True
    step6 = False
    
    fs = FeatureService(
            url=service_url,
            securityHandler=agolSH,
            proxy_port=proxy_port,
            proxy_url=proxy_url,
            initialize=True)  
    
    if step1:
        ldf = LayerDefinitionFilter()
        ldf.addFilter(1, where="MANUFACTURER='Mueller Company'")
        
        #Query for count
        print fs.query(layerDefsFilter=ldf,
                       returnCountOnly=True)
    if step2:
        ldf = LayerDefinitionFilter()
        ldf.addFilter(1, where="MANUFACTURER='Mueller Company'")
        ldf.addFilter(2, where="MATERIAL = 'PVC'")
        #Query for features, returns a common.general.featureset
        result = fs.query(layerDefsFilter=ldf,
                           returnCountOnly=False)
        print result[0].toJSON
        print result[1].toJSON
    if step3:
        result = fs.createReplica(replicaName='Demo', layers='0,1,2,3,4', keep_replica=False, 
                    layerQueries=None, 
                    geometryFilter=None, 
                    returnAttachments=True, 
                    returnAttachmentDatabyURL=False, 
                    returnAsFeatureClass=True, 
                    out_path='C:\\temp')
   
        print result
   
    if step4:                        
        fl = FeatureLayer(
            url=layer_url,
            securityHandler=agolSH,
            proxy_port=proxy_port,
            proxy_url=proxy_url,
            initialize=True)
        
        print fl.query(where="MATERIAL = 'PVC'",returnFeatureClass=True,out_fc="c:/temp/backup.shp")
        
    
    if step5:   
        portalAdmin = arcrest.manageorg.Administration(securityHandler=agolSH)
        content = portalAdmin.content
        
        item = content.item(itemId)
        uc =  content.usercontent(username=item.owner)
        res = uc.exportItem(title="TestExport",
                            itemId=itemId,
                            exportFormat="File Geodatabase")
        exportItemId = res['exportItemId']
        jobId = res['jobId']
        serviceItemId = res['serviceItemId']
        status = uc.status(itemId=exportItemId, jobId=jobId, jobType="export")
        while status['status'].lower() != 'completed':
            status = uc.status(itemId=exportItemId, jobId=jobId, jobType="export")
            if status['status'].lower() == 'failed':
                print status                
                break
        del status
        exportItem = content.item(exportItemId)
        itemDataPath = exportItem.itemData(f=None, savePath='C:\\temp')
        uc.deleteItem(item_id=exportItemId)
        print itemDataPath
    if step6:
     
        fieldToAdd = {
    
            "fields" : [
                {
                    "name" : "FUNWITHREST",
                    "type" : "esriFieldTypeString",
                    "alias" : "FUNFUN",
                    "sqlType" : "sqlTypeOther", "length" : 50,
                    "nullable" : True,
                    "editable" : True,
                    "domain" : None,
                    "defaultValue" : None
                }  ]
        }
        #agolServices = arcrest.hostedservice.Services(admin_url, securityHandler=agolSH)
        #for service in agolServices.services:
            #for lyr in service.layers:
                #if lyr.name.lower() == service_name.lower():
                    #print lyr.addToDefinition(fieldToAdd)
                    #break        
        lyr = arcrest.hostedservice.AdminFeatureServiceLayer(aurl=dmin_url, securityHandler=agolSH)
        
        print lyr.addToDefinition(fieldToAdd)
                      