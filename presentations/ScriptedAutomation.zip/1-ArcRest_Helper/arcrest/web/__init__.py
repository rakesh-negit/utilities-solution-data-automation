"""
   _web constructor
"""
import _base
__version__ = "2.0.100"