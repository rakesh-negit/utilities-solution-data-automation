from featureservice import *
from layer import *
from tiledservice import *

__version__ = "2.0.100"