import sys, io, os

from arcpyhelper import ArcRestHelper
from arcpyhelper import Common

import json

if __name__ == "__main__":
    step1 = False
    step2 = True
    
    username = "SolutionsPres"
    password = "123pliney"
   
    groupName = 'Portland Water Conf'
    fileName = "c:\\temp\\groupContent.json"
    iconPath = "c:\\temp\\icons"  
    
    configFile =  './configs/createservice.json'
  
    if step1:
        orgTools = ArcRestHelper.orgTools(username = username, password=password)
    
        if not os.path.exists(iconPath):
            os.makedirs(iconPath)                            
        file = io.open(fileName, "w", encoding='utf-8')                                               
        results = orgTools.getGroupContent(groupName=groupName)  
        groups=[]
        if 'results' in results:
            print results['results']
            for result in results['results']:
                thumbLocal = orgTools.getThumbnailForItem(itemId=result['id'],fileName=result['title'],filePath=iconPath)
                result['thumbnail']=thumbLocal
                groups.append(result)
                  
        if len(groups) > 0:
            file.write(unicode(json.dumps(groups, ensure_ascii=False, sort_keys=True, indent=4, separators=(',', ': '))))                                              
        file.close()   
        print "%s Created" % fileName
    
    if step2:
        pubTools = ArcRestHelper.publishingtools(username = username, password=password)
        config = Common.init_config_json(config_file=configFile)
        resultFS = pubTools.publishFsFromMXD(fs_config=config['FeatureServices'])
        print resultFS
        